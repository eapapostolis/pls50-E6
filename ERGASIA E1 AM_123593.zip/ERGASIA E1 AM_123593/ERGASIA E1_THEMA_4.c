
#include <stdio.h>
#include <stdlib.h>
   
    void main()
    
    {
    	
		// dilosi metablitwn
    	char pinakida[8];
    	int epilogi, theseis, i;
    	
    	/* dilwsi kiriou  pinaka P me plithos [54] giati den ginetai xrisi tou P[0]
		gia na uparxei sumfwnia me tous arithmous twn thesewn*/
    	int P[54];
    	
    	/* dilwsi voithitikou pinaka D gia epiloges 7 kai 8, me plithos [54] giati den ginetai xrisi tou D[0]
		gia na uparxei sumfwnia me tous arithmous twn thesewn*/
		char D[54];
		    		
    		
    	// anoigma arxeiou "bus.txt" apoktisi dedomenwn 
    	FILE *bus;
    	bus=fopen("bus.txt", "r");
    	if(bus==NULL)
    	printf("LATHOS");
    	
    	fscanf(bus," %s %d", pinakida, &theseis);
    	printf("\n\n\n\t   ARITHMOS KYKLOFORIAS: %s\tARITHMOS THESEWN: %d", pinakida, theseis);
    	fclose(bus);
    	
    	if(theseis>53)
    	{
    		printf("\n\n\t   YPERVASI ARITHMOY THESEWN");
    		exit(1);
    	}
    	if((theseis-5)%4!=0)
    	{
    		printf("\n\n\t   MH APODEKTI DIATAKSI");
    		exit(1);
    	}
    	
    	// arxikopoiisi pinaka P me "0" kai pinaka D me "_"
    	D[0]='#';
		for(i=1; i<=theseis; i++)
		D[i]='_';
    	
    	P[0]=999;
    	for(i=1; i<=theseis; i++)
    	P[i]=0;
    	
    		
    	// menu epilogwn
    	do
    	{	
    		printf("\n\n\t   MENU EPILOGWN");
    		printf("\n\t   -------------");
    		printf("\n\n\t1. EMFANISH PLHTHOYS KENWN THESEWN KAI TWN ARITHMWN TOUS");
    		printf("\n\n\t2. KRATHSH SYGKEKRIMENHS THESHS");
    		printf("\n\n\t3. KRATHSH THS PRWTHS KENHS THESHS SE PARATHYRO");
    		printf("\n\n\t4. AKYRWSH KRATHSHS SYGKEKRIMENHS THESHS");
    		printf("\n\n\t5. ANAZHTHSH AN EINAI KRATHMENH THESH ME SYGKEKRIMENO ARITHMO");
    		printf("\n\n\t6. EMFANISH TAKSINOMHMENHS LISTAS KRATHMENWN THESEWN");
    		printf("\n\n\t7. EMFANISH DIAGRAMMATOS LEWFORIOY KAI PINAKIDAS");
    		printf("\n\n\t8. APOTHHKEYSH DIAGRAMMATOS");
    		printf("\n\n\t0. EKSODOS");
    		printf("\n\n\n\t   EPELEKSE:");
    		scanf("%d",&epilogi);
    		
    	
    		// epilogi 1
    		if(epilogi==1)
    		{
    			int sum=0;
    			for(i=1; i<=theseis; i++)
    			{
    				if(P[i]==0)
    				sum=sum+1;
				}
    			printf("\n\t   PLITHOS KENWN THESEWN: %d\n\n",sum);
    			
    			printf("\t   ARITHMOI KENWN THESEWN: \n\n\t   ");
    			for(i=1; i<=theseis; i++)
    			{
    				if(P[i]==0)
    				{
    					if(i%10==0)
    					printf("\n\t  ");
    					printf("   %d ", i);
    				}
    			}
			}
			
			// epilogi 2
			if(epilogi==2)
			{
				int kra;
				
				printf("\n\t   DWSE ARITHMO THESHS GIA KRATHSH:");
				scanf(" %d",&kra);
				if(kra<=0||kra>theseis)
				printf("\n\t   LATHOS ARITHMOS");
				else if(P[kra]==1)
				printf("\n\t   H THESH EINAI PIASMENH");
				else 
				{
					P[kra]=1;
					printf("\n\t   H KRATHSH EGINE");
				}	
				
			}
			
			// epilogi 3
			if(epilogi==3)
    		{
    			for(i=1; i<=theseis; i++)
    			{
    				// entopismos tis prwtis kenis thesis se parathuro
    				if(P[i]==0 && ((i%4==0 && i!=theseis-1) || (i%4==1)))
   					{
					
   						printf("\n\t   H KRATHSH EGINE, ARITHMOS THESHS:%d", i);
   						P[i]=1;
    					break;	
   					}
   					
    				else if(i==theseis)
					printf("\n\t   OLES PIASMENES");	
				}
    			
			}
			
			// epilogi 4 
			if(epilogi==4)
			{
				int aki;
				
				printf("\n\t   DWSE ARITHMO THESHS GIA AKYRWSH:");
				scanf(" %d",&aki);
				if(aki<=0||aki>theseis)
				printf("\n\t   LATHOS ARITHMOS");
				else if(P[aki]==0)
				printf("\n\t   H THESH DEN EINAI PIASMENH");
				else 
				{
					P[aki]=0;
					printf("\n\t   H AKYRWSH EGINE");
				}	
				
			}
			
			// epilogi 5
			if(epilogi==5)
			{
				int anaz;
				
				printf("\n\t   DWSE ARITHMO THESHS GIA ANAZHTHSH:");
				scanf(" %d",&anaz);
				if(anaz<=0||anaz>theseis)
				printf("\n\t   LATHOS ARITHMOS");
				else if(P[anaz]==1)
				printf("\n\t   H THESH EINAI KRATHMENH");
				else if(P[anaz]==0)
				printf("\n\t   H THESH DEN EINAI KRATHMENH");
				
				
				
			}
			
			// epilogi 6
			if(epilogi==6)
    		{
				printf("\n\t   KATASTASH KRATHMENWN THESEWN\n");
    			for(i=1; i<=theseis; i++)
    			{
    				if(P[i]==1)
   					printf("\t   %d ",i);
						
				}
				 
			}
			
			// epilogi 7
			if(epilogi==7)
			{				
				printf("\n\n\t   %s", pinakida);
				
				// perasma ston voithitiko pinaka D twn kratisewn '*'
    			for(i=1; i<=theseis; i++)
    			{
    				if (P[i]==1)
    				D[i]='*';
    			}
    			
    			// dimiourgia tou diagramatos gia N=0 oxima 5 thesewn
				if (theseis==5)		
				printf("\n\t   %c %c %c %c %c", D[theseis-4], D[theseis-3], D[theseis-2], D[theseis-1], D[theseis]);
				
				// dimiourgia tou diagramatos gia N>0 oximata me 9-53 theseis
				else
				{
					for(i=1; i<=(theseis-5); i=i+4)
					printf("\n\t   %c %c   %c %c", D[i], D[i+1], D[i+2], D[i+3]);
					
					printf("\n\t   %c %c %c %c %c", D[theseis-4], D[theseis-3], D[theseis-2], D[theseis-1], D[theseis]);
				}
			}
				// epilogi 8
				if(epilogi==8)
				{
					//dimiourgia, anoigma arxiou "layout.txt" kai eggrafi sto arxio
					FILE *layout;
    				layout=fopen("layout.txt", "w");
    				
    				if(layout==NULL)
    				printf("LATHOS");
    				
    				fprintf(layout,"\n\n%s", pinakida);
    				
    				// perasma ston voithitiko pinaka D twn kratisewn '*'
    				for(i=1; i<=theseis; i++)
    			    {
    					if (P[i]==1)
    					D[i]='*';
    			    }
    			    
    			    // dimiourgia tou diagramatos gia N=0 oxima 5 thesewn
    				if (theseis==5)
					fprintf(layout, "\n%c %c %c %c %c", D[theseis-4], D[theseis-3], D[theseis-2], D[theseis-1], D[theseis]);
					
					// dimiourgia tou diagramatos gia N>0 oximata me 9-53 theseis
					else
					{
						for(i=1; i<=(theseis-5); i=i+4)
						fprintf(layout, "\n%c %c   %c %c", D[i], D[i+1], D[i+2], D[i+3]);
					
						fprintf(layout, "\n%c %c %c %c %c", D[theseis-4], D[theseis-3], D[theseis-2], D[theseis-1], D[theseis]);
					}
					printf("\n\t   OK");
					fclose(layout);
    					
				}
				
					
					
					
					
					
									
    			
    		    			
    	// epilogi 0 exksodo	
		}
    	while(epilogi!=0);
    	
	}
    
