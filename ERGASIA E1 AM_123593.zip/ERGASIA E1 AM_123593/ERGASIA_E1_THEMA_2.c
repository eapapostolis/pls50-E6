
   #include <stdio.h>
   #include <math.h>
   
   // dilwsi synartisewn 
   float tetragwno(float p);
   float parallilogrammo(float m, float p );
   float trigwno(float a, float b);
   float kyklos(float r);
   
     
main()
{
	// dilwsi metavlitwn
    int choice;
    float plevra, perimetro, mikos, platos, plevra1, plevra2, aktina;
    
   // pinakas epilogwn kai epilogi apo xristi
   do
   {
   		
   		printf("\n\n\n  YPOLIGISMOS PERIMETROY\n");
   		printf("  ----------------------\n\n");
   		printf("   1. GIA TETRAGWNO\n");
    	printf("   2. GIA PARALLILOGRAMO\n");
    	printf("   3. GIA ORTHOGWNIO TRIGWNO\n");
    	printf("   4. GIA KYKLOS\n");
    	printf("   0. GIA EKSODOS\n\n");
    	printf("   EPELEKSE:  ");
    
    	scanf(" %d", &choice);
    	
    	if (choice==1)
    	{
    		printf("\n  Dwse plevra: ");
    		scanf(" %f", &plevra);
    		perimetro=tetragwno(plevra);
    		printf("\nH perimetros tou tetragwnou einai: %.2f",perimetro );
	    }if (choice==2)
    	{
    		printf("\n  Dwse Mikos_Platos: ");
    		scanf(" %f %f", &mikos, &platos);
    		perimetro=parallilogrammo(mikos, platos);
    		printf("\nH perimetros tou parallilogrammou einai: %.2f",perimetro );
	    }
		if (choice==3)
    	{
    		printf("\n  Dwse Mikos Kathetwn plevrwn: ");
    		scanf(" %f %f" , &plevra1, &plevra2);
    		perimetro=trigwno(plevra1, plevra2);
    		printf("\nH perimetros tou trigwnou einai: %.2f",perimetro );
	    }
	    if (choice==4)
    	{
    		printf("\n  Dwse Aktina: ");
    		scanf(" %f", &aktina);
    		perimetro=kyklos(aktina);
    		printf("\nH perimetros tou kyklou einai: %.2f",perimetro );
	    }
	    
    }	
	while( choice!=0);
}
	//sunartiseis upologismou perimetrwn
    float tetragwno(float p)
    {
    	return (p*4);
	}
    float parallilogrammo(float m, float p )
    {
    	return (2*(m+p));
	}
    float trigwno(float a, float b)
    {
    	return(sqrt(a*a+b*b)+a+b);
	}
	float kyklos(float r)
	{
		return(3.14*r);
	}
    
