
 #include <stdio.h>
 
 main()
 
 {
 	//dilwsi metablitwn
 	int a, y, p,i;
 	const int d=2;
 	
 	//eisagwgi arithmou, minuma lathous
	do
 	{
 		printf("\n\nDWSE ENAN AKERAIO THETIKO ARITHMO:");
 		scanf(" %d",&a);
 		if(a<0) 
		printf("\nLATHOS  ");
		
    }
    while(a<0);
    printf("\n\n");
    
	//algorithmos euresis antistrofou diadikou arithmou kai emfanisi stin othoni
   	do
    {	
		y=a%d;
   		y==0? putchar('0'): putchar('1');
   		p=a/d;
   		a=p;
	}
    while(p!=0);
    
    
}
 
