

  #include <stdio.h>
  
  
  
  main()
  { 
  	// dilwsi metavlitwn
    float a,c;
    char b;
    
    // eisagwgi dedomenwn, upologismoi kai minumata lathous
    printf("DWSE ARITHMO_SYMBOLO PRAKSHS(+,-,*,/)_ARITHMO: ");
    scanf(" %f %c %f", &a, &b, &c);
    if (b=='+')
	printf("APOTELESMA= %.2f",a+c);
	else if (b=='-')
	printf("APOTELESMA= %.2f",a-c);
	else if (b=='*')
	printf("APOTELESMA= %.2f",a*c);
	else if (b=='/')
	{ 
		if (c==0)
		printf("ADYNATH, DIAIRESH ME 0");
		else 
		printf("APOTELESMA= %.2f",a/c);
    }
    else 
	printf("LATHOS DWSE ENA APO TA: +, -, *, /");
    	
  }
