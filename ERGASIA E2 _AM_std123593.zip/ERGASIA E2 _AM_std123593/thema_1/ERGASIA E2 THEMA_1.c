
  #include <stdio.h>
  #include <string.h>
  #include <stdlib.h>
  # define N 46
  
  //DHLWSH DOMHS TYPOY <epivatis>
  struct epivatis
  { 
  	char name[40];
	unsigned short phone[10];
	unsigned int seat;
  }; 
  //DHLWSH SYNARTHSEWN KAI OPISMOS SYNTOMOGRAFIAS GIA TO <struct epivatis>
  typedef struct epivatis epivatis;
  void load(epivatis *p, char *pinak, int *the);
  void epilogi1(epivatis *p);
  void epilogi2(epivatis *p, int t);
  void epilogi3(epivatis *p);
  void epilogi4(epivatis *p);
  void epilogi5(epivatis *p);
  void save(epivatis *p, char *pinak, int the);
  
  
  main()
  { 
  	int i,n,k,epilogi,thesi,theseis;
	char pinakida[8];
  	epivatis P[N];
  	
  	//ARXIKOPOIHSH ONOMA, THLEPHONO, THESH 
	  for(i=1;i<N;i++)
  	{ 
	  	for(k=0;k<40;k++)
		P[i].name[k]='\0';
	
		for(n=0;n<10;n++)
		P[i].phone[n]=0;
    	
  		P[i].seat=0;
    } 
    
    load(P,pinakida,&theseis);
    
    //EKTYPWSH KRATHMENWN THESHWN
    for(i=1;i<N;i++)
    {
    	if(P[i].seat!=0)//EKTYPWSH KATAXVRHSEWN
		{
			printf("\n%s %u ", P[i].name,P[i].seat);
			for(n=0;n<10;n++)
    		printf("%hu",P[i].phone[n]);
    	}
    }
    do	
	{
		printf("\n\n\t   MENU EPILOGWN");
    	printf("\n\t   -------------");
    	printf("\n\n 1. EMFANISH PLHTHOYS KENWN THESEWN KAI TAKSINOMHMENHS LISTAS TWN ARITHMWN TOUS");
    	printf("\n\n 2. KRATHSH THESHS ME SYGKEKRIMENO ARITHMO KAI STOIXEIA EPIBATH");
    	printf("\n\n 3. ANAZHTHSH AN EINAI KRATHMENH THESH SE SYGKEKRIMENO ONOMA H THLEPHWNO");
		printf("\n\n 4. AKYRWSH KRATHSHS SYGKEKRIMENHS THESHS");
    	printf("\n\n 5. EMFANISH  LISTAS ME STOIXEIA EPIBATWN TAKSINOMHMENHS KATA ARITHMO THESEHS");
    	printf("\n\n 0. EKSODOS");
    	printf("\n\n\n    EPELEKSE:");
    	scanf("%d",&epilogi);
    	
    	//YLOPOIHSH EPILOGWN KYRIOY MENOY
    	switch(epilogi)
    	{
    		case 1:
    		epilogi1(P);
    		break;
    		
    		case 2:
    		printf("\nDWSE TON ARITHMO THESHS GIA KRATHSH:");
    		scanf(" %d",&thesi);
    		epilogi2(P, thesi);
    		break;
    		
    		case 3:
    		epilogi3(P);
    		break;
    		
    		case 4:
    		epilogi4(P);
    		break;
    		
    		case 5:
    		epilogi5(P);
    		break;	
    		
    	    case 0:
    	    save(P,pinakida,theseis);
    	    break;
    	    
    	default:
    	printf("LATHOS EPILOGH");
		}	
	
    }
    while(epilogi!=0);
  }
  //------------------------------
 void load(epivatis *p, char *pinak, int *the)
  { 
  
	int i;
	char fn[20], sn[20];
	unsigned short ph[10];
	unsigned int s;
	
	//ANOIGMA ARXEIOY <bus>	
   	FILE *bus;
  	bus=fopen("bus.txt","r");
  	if(bus==NULL) // AN YPARKSEI PROBLHMA ME TO ANOIGMA TOY ARXEIOY
   {
      printf("TO ARXEIO DEN MPOREI NA ANAGNWSTEI\n");
      exit(1);      
   }
    fscanf(bus," %s %d", pinak, the);// DIAVAZEI APO TO ARXEIO PINAKIDA KAI ARITHMO THESEWN
    
		
	while(!feof(bus)) //DIABAZEI APO TO ARXEIO MEXRI TO TELOS TA STOIXEIA TWN EPIBATWN KAI TA PERNAEI STON PINAKA 
	{
	fscanf(bus,"%s %s %u",fn,sn,&s);
	
	for(i=0;i<10;i++)
	fscanf(bus,"%1hu",&ph[i]);
	
  	strcpy(p[s].name,fn);
  	strcat(p[s].name," ");
  	strcat(p[s].name,sn);
  	p[s].seat=s;
  	
  	for(i=0;i<10;i++)
  	p[s].phone[i]=ph[i];
  	}
  	fclose(bus);
	printf("%s %d", pinak, *the);//EKTYPWSH PINAKIDAS KAI ARITHMOY THESHS 
  }
  
  //YLOPOIHSH SYNARTHSEWN GIA TO MENOY EPILOGWN
  void epilogi1(epivatis *p) 
  {
  	int i,sum=0;
  	for(i=1;i<N;i++)
  	{
		if(p[i].seat==0)
		sum=sum+1;
	}
	printf("\n\nARITHMOS KENWN THESEWN: %d\n\n",sum);
	printf("lISTA KENWN THESEWN\n");
  	for(i=1;i<N;i++)
  	{ 
	  if(p[i].seat==0)
	  printf("%d\t ",i);	 	  	
	}
  }
  
 void epilogi2(epivatis *p, int t)
 {
 	int i;
 	unsigned short ph[10]; 
	char fn[20],sn[20];
		
 	if(t<1||t>53)
 	printf("LATHOS ARITHMOS THESHS");
 	if(p[t].seat!=0)
 	printf("H THESH EINAI KRATHMENH");	
	else
	{
		printf("DWSE EPITHETO:");
		scanf( " %s",fn);
		printf("DWSE ONOMA:");
		scanf( " %s",sn);
		strcpy(p[t].name,fn);
		strcat(p[t].name," ");
		strcat(p[t].name,sn);
		p[t].seat=t;
		
		printf("DWSE THLEFWNO:");
		for(i=0;i<10;i++)
		scanf( "%1hu",&p[t].phone[i]);
		printf("\nH KRATHSH EGINE");
				
	}
 }
 
 void epilogi3(epivatis *p)
 {
 	int i,n,choise,cmp ;
 	int sum=0,pointer=1;
 	unsigned short ph[10]; 
	char fn[20],sn[20],fullname[40];
 	
 	printf("    \n\nMENOY EPILOGWN\n\n");
 	printf(" 1. ANAZHTHSH ME ONOMATEPWNYMPO\n");
	printf(" 2. ANAZHTHSH ME THLEFWNO\n\n");
	printf("    EPELEGSE:");
	scanf("%d",&choise);
	
	switch(choise)
	{
		case 1:
		printf("    DWSE EPITHETO:");
		scanf( " %s",fn);
		printf("    DWSE ONOMA:");
		scanf( " %s",sn);
		strcpy(fullname,fn);
		strcat(fullname," ");
		strcat(fullname,sn);
		
		for(i=1;i<N;i++)
		{
			cmp=strcmp(p[i].name,fullname);
			if(cmp==0)
		    {
				printf("\n  YPARXEI KRATHSH STO ONOMA:%s",fullname);
		    	pointer=0;
			}
		}
		if(pointer!=0)
		printf("\n  DEN YPARXEI KRATHSH STO ONOAMA:%s",fullname);
		break;
		
		case 2:
		printf("\nDWSE THLEFWNO:");
		for(n=0;n<10;n++)
		scanf("%1hu",&ph[n]);
		
		for(i=1;i<N;i++)//ANAZHTHSH KRATHSEWN
		{
				if(p[i].phone[0]==ph[0]&&p[i].phone[1]==ph[1]&&p[i].phone[2]==ph[2]&&p[i].phone[3]==ph[3]&&
				p[i].phone[4]==ph[4]&&p[i].phone[5]==ph[5]&&p[i].phone[6]==ph[6]&&p[i].phone[7]==ph[7]&&
				p[i].phone[8]==ph[8]&&p[i].phone[9]==ph[9])
				printf("YPARXEI KRATHSH");
	    }
		
		break;
	}
 	
 }
 
 void epilogi4(epivatis *p)
 {
 	int i,thesi,n;
 	
 	printf("\nDWSE ARITHMO THESHS GIA AKYRWSH:");
 	scanf(" %d",&thesi);
 	
 	for(i=0;i<40;i++)
	p[thesi].name[i]='\0';
 	for(n=0;n<10;n++)
  	p[thesi].phone[n]=0;	
	p[thesi].seat=0;
	printf("H AKYRWSH EGINE");	 
  		
 }
 
 void epilogi5(epivatis *p)
 {
 	int i,n;
 	
 	for(i=1;i<N;i++)
 	if(p[i].seat!=0)
 	{
		printf("\n\n%s %u ",p[i].name,p[i].seat);
 		for(n=0;n<10;n++)
 		printf("%hu",p[i].phone[n]);
 	}
 	
 }
 //DHMOYRGIA ARXEIOY EKSODOY
 void save(epivatis *p, char *pinak, int the)
{
	
	int i,n;	
	
	FILE *busout;
	busout=fopen("busout.txt","w");
	if(busout==NULL) //se periptwsi problimatos kata to anoigma
    {
      printf("TO ARXEIO DEN MPOREI NA EGGRAFEI\n");
      exit(1); //ejodos apo to programma
	}    
	fprintf(busout,"%s %d", pinak, the);
	 
 	for(i=1;i<N;i++)
 	{
		if(p[i].seat!=0)
		{
			fprintf(busout,"\n\n%s %u ",p[i].name,p[i].seat);
 			for(n=0;n<10;n++)
 			fprintf(busout,"%hu",p[i].phone[n]);
 		}
 	}
 	fclose(busout);
  } 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
