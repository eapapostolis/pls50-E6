 
 #include <stdlib.h>
 #include <time.h>
 #include <stdio.h>
 
 //DHLWSH DOMWN KAI SYNARTHSEWN
 struct PLAYER 
 {
 	char name[17];
 	int score;
 	char id;
 };
 struct CARD
 {
 	char colour;
	char shape;
 	unsigned int number;
 	char texture;
 };
 typedef struct PLAYER player;
 typedef struct CARD card;
 void getNextCard(card p[] [4]);
 void checkCards(card p[] [4], int *change);

 main()
 {
 	int epilogi;
 	int CHANGE=0;
 	char ID;
 	//ARXIKOPOIHSH STIGMIOTYPWN TYPOY <player>
 	player a={"Marina Andreou  ", 0,'a'};
 	player g={"Kostas Grammenos", 0,'g'};
 	player p={"Maria Perdika   ", 0,'p'};
 	card AC[3] [4];
 	
 	
 	srand(time NULL);//ARXIKOPOIHSH <rad()>
 	
 	do //EKSWTERIKO LOOP GIA THN PERIPTWSH POY O PAIKTHS DWSEI SWSTH APANTHSH (OI KARTES ALLAZOYN)
 	{
	 	getNextCard(AC);//PERASMA TYXAIWN DEDOMENWN STIS KARTES, STIGMIOTYPA TOY PINAKA <AC>
 		
 		do //ESWTERIKO LOOP GIA THN PERIPTWSH POY OI PAIKTES DINOYN LATHOS APANTHSEIS (OI KARTES DEN ALLAZOYN)
 	 	{
			printf("\n\n  MENU EPILOGWN");
			printf("\n\n  --------------");
 			printf("\n\n  0. EKSODO");
 			printf("\n\n  1. EISAGWGH ID");
 			printf("\n\n  EPILOGH: ");
			scanf(" %d",&epilogi);
			
			if(epilogi==0)
			break;
			
			if(epilogi==1)
			{
				printf("\n  DWSE TO ID SOY: ");
				scanf(" %c",&ID);
				checkCards(AC, &CHANGE);//EISAGWGH APO TON PAIKTH SYNTETAGMENWN KARTWN KAI ELEGXOS GIA SWSTO H LATHOS
				
				// YPOLOGISMOS SCORE PAIKTWN
				if(ID=='a')
				{
				 a.score=a.score+CHANGE;
				 
				 if(a.score==-1) a.score=0;//TO SCORE TOY PAIKTH DEN GINETAI LIGOTERO APO 0
				 	
				 if(a.score==10)//EKTYPWSH PONTWN KAI TERMATISMOS AN O PAIKTHS EXEI SCORE 10
				  {
					if(g.score==-1) g.score=0;
					if(p.score==-1) p.score=0;
					printf("\n%s   %d   %c",a.name, a.score, a.id);
					printf("\n%s   %d   %c",g.name, g.score, g.id);
					printf("\n%s   %d   %c",p.name, p.score, p.id);
					printf("\n\n  O NIKHTHS EINAI:%s",a.name);
					exit(1);
				  }
				}
				
				//EPANALHPSH TWN PARAPANW GIA TOYS YPOLOIPOYS PAIKTES
				if(ID=='g')
				{
				 g.score=g.score+CHANGE;
								 
				 if(g.score==-1) g.score=0;
			      
				 if(g.score==10)
				  {
					if(a.score==-1) a.score=0;
					if(p.score==-1) p.score=0;
					printf("\n%s   %d   %c",a.name, a.score, a.id);
					printf("\n%s   %d   %c",g.name, g.score, g.id);
					printf("\n%s   %d   %c",p.name, p.score, p.id);
					printf("\n\n  O NIKHTHS EINAI:%s",g.name);
					exit(1);
				  }
				}
				
				if(ID=='p')
				{
				 p.score=p.score+CHANGE;
				 
				 if(p.score==-1) p.score=0;
				 
				 if(p.score==10)
				  {
					if(a.score==-1) a.score=0;
					if(g.score==-1) g.score=0;
					printf("\n%s   %d   %c",a.name, a.score, a.id);
					printf("\n%s   %d   %c",g.name, g.score, g.id);
					printf("\n%s   %d   %c",p.name, p.score, p.id);
					printf("\n\n  O NIKHTHS EINAI:%s",p.name);
					exit(1);
				  }
				}
			}
			
		}
		while(CHANGE==-1);/*TO LOOP TREXEI OSO OI PAIKTES DINOYN LATHOS APANTHSEIS(OI KARTES DEN ALLAZOYN)
		AN O PAIKTHS DWSH SWSTH APANTHSH PERNAME STO EKSOTERIKO LOOP (OI KARTES ALLAZOYN)*/
		
	}
	while(epilogi!=0);//EPILOGH 0 EKSODO KAI EKTYPWSH APOTELASMATWN
	
	    if(a.score==-1) a.score=0;
		if(p.score==-1) p.score=0;
		if(g.score==-1) g.score=0;
		printf("\n%s   %d   %c",a.name, a.score, a.id);
		printf("\n%s   %d   %c",g.name, g.score, g.id);
		printf("\n%s   %d   %c",p.name, p.score, p.id);		 	
 	
 }
 
 void getNextCard(card p[] [4])//SYNARTHSH DHMIOYRGIAS TYXAIWN DEDOMENWN STIS KARTES
 {
 	unsigned int x,ln,clmn,l,c;
 	
 	for(ln=0;ln<3;ln++)
 	{
	 	for(clmn=0;clmn<4;clmn++) 
		{
	 		x=(rand()%3)+1;// TYXAIES TIMES APO 1 EWS 4 GIA <colour>
			switch(x)//METATROPH SE XRWMATA
			{
				case 1:
				p[ln] [clmn].colour='r';
				break;
				case 2:
				p[ln] [clmn].colour='g';
				break;
				case 3:
				p[ln] [clmn].colour='b';
				break;
		
			}
			//EPANALHPSH TWN PARAPANW GIA TA YPOLOIPA XARAKTHRISTIKA TWN KARTWN
			x=(rand()%3)+1;
			switch(x)
			{
				case 1:
				p[ln] [clmn].shape='c';
				break;
				case 2:
				p[ln] [clmn].shape='t';
				break;
				case 3:
				p[ln] [clmn].shape='r';
				break;
			}	
			x=(rand()%3)+1;
			switch(x)
			{
				case 1:
				p[ln] [clmn].number=x;
				break;
				case 2:
				p[ln] [clmn].number=x;
				break;
				case 3:
				p[ln] [clmn].number=x;
				break;
		
			}
			x=(rand()%3)+1;
			switch(x)
			{
				case 1:
				p[ln] [clmn].texture='b';
				break;
				case 2:
				p[ln] [clmn].texture='h';
				break;
				case 3:
				p[ln] [clmn].texture='e';
				break;
			}			
		}
	}
	//EKTYPWSH PINAKA KARTWN
	printf("\n\n--------------------------------------------------------------------\n");
	for(ln=0;ln<3;ln++)
 	{
	 	for(clmn=0;clmn<4;clmn++) 
		printf("[ %c  %c  %hu  %c ]    ",p[ln] [clmn].colour,p[ln] [clmn].shape,
		p[ln] [clmn].number,p[ln] [clmn].texture);
    	printf("\n");
	}
	printf("--------------------------------------------------------------------\n\n\n");
	
	//ELEGXOS GIA DIPLOTYPA 
	for(ln=0;ln<3;ln++)
 	{
	 	for(clmn=0;clmn<4;clmn++)
	 	{
			for(l=0;l<3;l++)
 			{
 				for(c=0;c<4;c++)
 				{
				 	if(p[ln][clmn].colour==p[l][c].colour&&//ELEGXOS GIA DIPLOTYPA
					   p[ln][clmn].shape==p[l][c].shape&&
					   p[ln][clmn].number==p[l][c].number&&
					   p[ln][clmn].texture==p[l][c].texture&&
					   ln!=l)
						{	   	
					   		system("cls");//SBHNEI TOYS PINAKES ME DIPLOTYPA
 					   		getNextCard(p);//H SYNARTHSH KALEI TON EAYTO THS OSO EXOYME DIPLOTYPA
 					   		
 					    }
 					   
 				}
 			}
 		}
 	}
 	
 					
 					
 					
 					
}
void checkCards(card p[] [4], int *change)//ELEGXOS GIA SWSTH APANTHSH
{
	//EISAGWGH THESEWN KARTWN
 	int x1, x2, x3, y1, y2, y3;
	printf("\n\n  KANE EPILOGH TWN KARTWN DINONTAS X GRAMMH,Y STHLH");
	do
	{
		printf("\n  DWSE X1:");
		scanf(" %d",&x1);
		if(x1<0||x1>2) printf("\n  LATHOS, DWSE: 0, 1, 2");
	}
	while(x1<0||x1>2);
	do
	{
		printf("\n  DWSE Y1:");
		scanf(" %d",&y1);
		if(y1<0||y1>3) printf("\n  LATHOS, DWSE: 0, 1, 2, 3");
	}
	while(y1<0||y1>3);
	
	do
	{
		printf("\n  DWSE X2:");
		scanf(" %d",&x2);
		if(x2<0||x2>2) printf("\n  LATHOS, DWSE: 0, 1, 2");
	}
	while(x2<0||x2>2);
	do
	{
		printf("\n  DWSE Y2:");
		scanf(" %d",&y2);
		if(y2<0||y2>3) printf("\n  LATHOS, DWSE: 0, 1, 2, 3");
	}
	while(y2<0||y2>3);
	do
	{
		printf("\n  DWSE X3:");
		scanf(" %d",&x3);
		if(x3<0||x3>2) printf("\n  LATHOS, DWSE: 0, 1, 2");
	}
	while(x3<0||x3>2);
	do
	{
		printf("\n  DWSE Y3:");
		scanf(" %d",&y3);
		if(y3<0||y3>3) printf("\n  LATHOS, DWSE: 0, 1, 2, 3");
	}
	while(y3<0||y3>3);
	
	//ELEGXOS GIA SWSTH APANTHSH		
	if( ( (p[x1][y1].colour==p[x2][y2].colour&&p[x2][y2].colour==p[x3][y3].colour)||
	      (p[x1][y1].colour!=p[x2][y2].colour&&p[x2][y2].colour!=p[x3][y3].colour&&
		   p[x3][y3].colour!=p[x1][y1].colour) )&&
		( (p[x1][y1].shape==p[x2][y2].shape&&p[x2][y2].shape==p[x3][y3].shape)||
	      (p[x1][y1].shape!=p[x2][y2].shape&&p[x2][y2].shape!=p[x3][y3].shape&&
		   p[x3][y3].shape!=p[x1][y1].shape) )&&
		( (p[x1][y1].number==p[x2][y2].number&&p[x2][y2].number==p[x3][y3].number)||
	      (p[x1][y1].number!=p[x2][y2].number&&p[x2][y2].number!=p[x3][y3].number&&
		   p[x3][y3].number!=p[x1][y1].number) )&&
		( (p[x1][y1].texture==p[x2][y2].texture&&p[x2][y2].texture==p[x3][y3].texture)||
	      (p[x1][y1].texture!=p[x2][y2].texture&&p[x2][y2].texture!=p[x3][y3].texture&&
		   p[x3][y3].texture!=p[x1][y1].texture) ) )
	*change=2;//SWSTH APANTHSH 2 VATHMOI
	else 
	{
		*change=-1;//LATHOS APANTHSH -1 VATHMOI
		printf("\n  PAIZEI O EPOMENOS\n");
	}
	
}


 	
 
 
 
